[About]
DirectStorageFix prevents GTAV Enhanced from opening a handle for every single file in the game directory when DirectStorage is enabled.
Instead, only .rpf and .cache files are allowed.

If you use scripts that write to existing log files, config files, or other data files in the game directory, this fix will restore their ability to write to those files.
Additionally, script developers can also reload their scripts at run-time again. It is currently only needed for game version 1.0.1013.17 and later.

[Requirements]
* ASI Loader (xinput1_4.dll) => http://www.dev-c.com/gtav/scripthookv/

[Installation]
Simply drop DirectStorageFix.asi into your GTAV Enhanced folder (where GTA5_Enhanced.exe is).

[Changelog]
1.2
* More logging improvements (Windows build and DirectStorage status)

1.1
* Game builds < 1013 are now ignored
* Logging improvements

1.0.1
* Fixed incorrect Windows build number detection

1.0
* Initial release
